/* File:     RandomChange.h
 * Purpose:  Header file for RandomChange.c.
 */
#ifndef _MY_RandomChange_H_
#define _MY_RandomChange_H_

void GetRandomSequence(int total,int size , float* Seq);
void changePosition(float *positions , int size);

#endif
