file_name = '../data/data_for_test.txt';  % out file name
file_name_cid = '../data/data_for_test_cid.txt';  % cid out file name   
file_input = '../data/modzs_n272x978.gctx'; % input file name（ .gctx ）

PreGSEA


