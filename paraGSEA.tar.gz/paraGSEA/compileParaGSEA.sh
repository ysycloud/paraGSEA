#!/bin/bash
make all